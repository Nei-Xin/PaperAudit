def accuracy():
    return 0.95
